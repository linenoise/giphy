package Imager::File::CUR;
use strict;

# all the work is done by Imager::File::ICO
use Imager::File::ICO;

1;
